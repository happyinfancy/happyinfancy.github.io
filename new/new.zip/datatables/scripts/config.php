<?php
$db_username 	= 'USERNAME';
$db_password 	= 'PASSWORD';
$db_name 		= 'DB_NAME';
$db_host 		= 'HOST';
?>